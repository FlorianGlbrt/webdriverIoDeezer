import { ChainablePromiseElement } from 'webdriverio';


export default class FavoritesActivity {

	private driver : WebdriverIO.Browser
	
	private get btnPlaylists(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[contains(@text, 'Playlists')]")
    }

 

	constructor (driver : WebdriverIO.Browser){
		this.driver = driver
	}
	
	public async goToPlaylists() : Promise<void>{
		console.log("go to playlists");
		await this.btnPlaylists.click();
	}

}
