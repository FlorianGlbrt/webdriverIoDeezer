import { ChainablePromiseElement } from 'webdriverio';

export default class HomeActivity {

	private driver : WebdriverIO.Browser
	
	
	private get btnFavorites(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[contains(@text, 'Favoris')]")
    }

	private get btnCloseCta(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[contains(@resource-id, 'secondary_cta')]")
    }

 

	constructor (driver: WebdriverIO.Browser){
		this.driver = driver;
	}

	public async closeCta(): Promise<void> {
		try {
			console.log("closing cta")
			await this.btnCloseCta.click();
		} catch {
			console.log("cta already closed")
		}
	}
	
	public async goToFavorites() : Promise<void>{
		console.log("go to favorites");
		await this.btnFavorites.click();
	}

}
