import { ChainablePromiseElement } from 'webdriverio';

export default class LaunchActivity {
    private driver : WebdriverIO.Browser;

    private get btnLogin(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[contains(@resource-id, 'enter_email_arrow')]")
    }

    public async goToLogin(): Promise<void> {
        await this.btnLogin.click()
    }

    constructor(driver: WebdriverIO.Browser) {
        this.driver = driver;
    }
}