import { ChainablePromiseElement } from 'webdriverio';


export default class PasswordLoginActivity {

	private driver : WebdriverIO.Browser
	
	private get inputPwd(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[contains(@resource-id, 'input')]")
    }

	private get btnPwd(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[contains(@resource-id, 'continue_btn')]")
    }
 

	constructor (driver : WebdriverIO.Browser){
		this.driver = driver
	}
	
	public async login(pwd : string) : Promise<void>{
		console.log("input pwd " + pwd);
		await this.inputPwd.setValue(pwd);
		await this.btnPwd.click();
	}

}
