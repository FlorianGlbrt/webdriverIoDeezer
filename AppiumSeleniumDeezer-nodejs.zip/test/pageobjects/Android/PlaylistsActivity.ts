import { ChainablePromiseElement } from 'webdriverio';


export default class PlaylistsActivity {

	private driver : WebdriverIO.Browser
	
	private txtPlaylistName(playlistName : string): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[contains(@content-desc, '"+ playlistName +"')]")
    }

 

	constructor(driver : WebdriverIO.Browser){
		this.driver = driver
	}
	
	public async isPlaylistPresent(playlistName : string) : Promise<void>{
		console.log("check if playlist is present");
		await this.txtPlaylistName(playlistName).waitForDisplayed({timeout: 5000})
	}

}
