import { ChainablePromiseElement } from 'webdriverio';

export default class EmailLoginActivity {

	private driver : WebdriverIO.Browser;

	private get inputLogin(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[@resource-id='deezer.android.app.nobilling:id/input']")
    }

	private get btnEmail(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[@resource-id='deezer.android.app.nobilling:id/continue_btn']")
    }

	constructor(driver: WebdriverIO.Browser) {
        this.driver = driver;
    }
	
	public async fillEmailAndGoToPwdPage(email : string) : Promise<void>{
		console.log("input email " + email)
		await this.inputLogin.setValue(email)
		await this.btnEmail.click()
	}

}
