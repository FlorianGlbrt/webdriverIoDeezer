import { ChainablePromiseElement } from 'webdriverio';

export default class PlaylistsPage {

	private driver: WebdriverIO.Browser
	private get btnAddNewPlaylist(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[@aria-label='Créer une playlist']")
    }
	
	private get inputPlaylistName(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[@class='playlist-assistant-form-input']")
    }

	private get btnCreatePlaylist(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//button/span[contains(text(), 'Créer')]")
    }
	
	

	constructor(driver : WebdriverIO.Browser){
		this.driver = driver
	}


	public async createPlaylist(name : string) : Promise<void>{
		console.log("Creating new playlist " + name);
		await this.btnAddNewPlaylist.click();
		await this.inputPlaylistName.setValue(name);
		await this.btnCreatePlaylist.click();
		console.log("Checking playlist created")
		
		await this.driver.$("//*[contains(text(), '"+ name +"')]").waitForDisplayed()
	}
}
