import { ChainablePromiseElement } from 'webdriverio';


export default class RegisterPage {

	private driver: WebdriverIO.Browser
	
	private get btnEnableCookies(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[@id='gdpr-btn-accept-all']")
    }
	
	private get btnRegister(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("#register_form_submit")
    }
	
	private get inputEmail(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("#register_form_mail_input")
    }
	
	private get inputUsername(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("#register_form_username_input")
    }

	private get inputPwd(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("#register_form_password_input")
    }

	private get inputAge(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("#register_form_age_input")
    }

	private get inputGender(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("#register_form_gender_input")
    }

 

	constructor(driver : WebdriverIO.Browser){
		this.driver = driver;
	}

	
	public async clickregister() : Promise<void>{
		await this.btnRegister.waitForClickable({timeout : 10000})
		await this.btnRegister.click()
	}

	public async goToRegisterPage() : Promise<void>{
		await this.driver.url("https://www.deezer.com/fr/register");
		try {
			console.log("Enabling cookies")
			await this.btnEnableCookies.click()
		} catch {
			console.log("cookies already enabled")
		}
		
	}
	

	/**
	 * Is used to register to Deezer
	 * @param strUserName
	 * @param strPassword
	 * @param strEmail
	 * @return
	 */
	public async fillRegisterForm(strUserName : string,strPassword : string, strEmail: string): Promise<void>{
		
		console.log("Registering + " + strEmail + ", " + strPassword + ", " + strPassword);
		await this.inputEmail.setValue(strEmail)
		await this.inputUsername.setValue(strUserName)
		await this.inputPwd.setValue(strPassword)
		await this.inputAge.setValue("18")
		await this.inputGender.selectByAttribute("value", "M")
				
	}
}
