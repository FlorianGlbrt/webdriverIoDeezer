import { ChainablePromiseElement } from 'webdriverio';

export default class HomePage {

	private driver : WebdriverIO.Browser

	private get btnPlaylist(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//span[contains(text(), 'Playlists')]")
    }

	private get btnProfil(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[@class='topbar-profile']")
    }

	private get closePopup(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("#modal-close")
    }

	private get pcClosePopup(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[@id='dzr-app']/div/div[1]/div/div/div[2]/div[2]/button")
	}
	
	

	constructor(driver : WebdriverIO.Browser){
		this.driver = driver
		
	}

	public async waitForLoad() : Promise<void>{
		await this.btnProfil.waitForDisplayed({timeout : 60000})
		console.log("home loaded")
	}
	public async closePopups() : Promise<void> {
		console.log("In Home Page");
		await this.driver.waitUntil(() =>{
			return (this.closePopup.isExisting()) || (this.pcClosePopup.isExisting())
		}, {timeout : 60000})
		console.log("if pop ups are present, disabling them");
		if (await this.closePopup.isExisting()) await this.closePopup.click()
		if (await this.pcClosePopup.isExisting()) await this.pcClosePopup.click()
		console.log("Popups disabled")
	}


	public async goToPlaylist() : Promise<void>{
		console.log("Going to Playlists page");
		await this.btnPlaylist.click();
	}
}
