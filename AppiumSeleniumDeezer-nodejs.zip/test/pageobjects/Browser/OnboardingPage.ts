import { ChainablePromiseElement } from 'webdriverio';

export default class OnboardingPage {

	private driver : WebdriverIO.Browser
	
	private get firstArtist(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[@class='onboarding-screen-artist-item'][1]")
    }
	private get secondArtist(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[@class='onboarding-screen-artist-item'][2]")
    }
	private get thirdArtist(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[@class='onboarding-screen-artist-item'][3]")
    }

	
	private get btnOnboarding(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//button/span[contains(text(), 'CONTINUER')]")
    }
	
	
	

	constructor(driver : WebdriverIO.Browser){
		this.driver = driver;
	}
	
	public async waitForLoad(): Promise<void> {
		await this.firstArtist.waitForClickable({timeout : 60000})
	}

	public async onboard() : Promise<void>{
		console.log("onboarding")
		await this.firstArtist.click()
		await this.secondArtist.click()
		await this.thirdArtist.click()
		await this.btnOnboarding.click()
	}
}
