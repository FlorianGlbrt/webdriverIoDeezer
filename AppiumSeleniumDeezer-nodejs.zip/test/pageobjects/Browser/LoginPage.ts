import { ChainablePromiseElement } from 'webdriverio';


export default class LoginPage {

	private driver : WebdriverIO.Browser
	private get btnEnableCookies(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[@id='gdpr-btn-accept-all']")
    }
	
	private get inputEmail(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("//*[@id='login_mail']")
    }
	
	private get inputPwd(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("#login_password")
    }
	
	private get btnLogin(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return this.driver.$("#login_form_submit")
    }


	constructor(driver : WebdriverIO.Browser){
		this.driver = driver
	}

	
	public async login(email : string,password : string) : Promise<void>{
		console.log("Log in to Deezer")
		await this.inputEmail.setValue(email)
		await this.inputPwd.setValue(password)
		await this.btnLogin.waitForClickable({timeout : 5000})
		await this.btnLogin.click()
	}

	public async goToLoginPage() : Promise<void>{
		console.log("Going to Deezer Login Page");
		await this.driver.url("https://www.deezer.com/fr/login")
		try {
			console.log("enabling cookies")
			this.btnEnableCookies.click()
		} catch {
			console.log("cookies already enabled")
		}
	}
	

}
