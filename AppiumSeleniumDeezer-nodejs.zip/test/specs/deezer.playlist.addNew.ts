import EmailLoginActivity from '../pageobjects/Android/EmailLoginActivity';
import LaunchActivity from  '../pageobjects/Android/LaunchActivity';
import request from "supertest";
import RegisterPage from '../pageobjects/Browser/RegisterPage';
import HomePage from '../pageobjects/Browser/HomePage';
import OnboardingPage from '../pageobjects/Browser/OnboardingPage';
import LoginPage from '../pageobjects/Browser/LoginPage';
import PlaylistsPage from '../pageobjects/Browser/PlaylistsPage';
import PasswordLoginActivity from '../pageobjects/Android/PasswordLoginActivity';
import HomeActivity from '../pageobjects/Android/HomeActivity';
import FavoritesActivity from '../pageobjects/Android/FavoritesActivity';
import PlaylistsActivity from '../pageobjects/Android/PlaylistsActivity';


describe('Add new playlist and check in Android App', () => {
    let email = ""
    let username = ""
    let password = ""
    let playlistName = "PlaylistTest"

    before('create an account', async() =>{
        console.log("Creating new account")
        await request("https://api.mockaroo.com/api").post("/28db36c0?count=1&key=da8527f0").expect((res) => {
            console.log(res.body)
            let first_name : string = res.body[0].first_name
            let last_name : string = res.body[0].last_name
            let number : string = res.body[0].number
            let pwd : string = res.body[0].pwd

            username = first_name + "." + last_name + "." + number
            email = username + "@email.ghostinspector.com";
            password = pwd + "!!";  
        })

        let registerPage : RegisterPage = new RegisterPage(multiremotebrowser['browserDriver'])
        await registerPage.goToRegisterPage()
        await registerPage.fillRegisterForm(username, password, email)
        await registerPage.clickregister()

        console.log("YOU MAY HAVE TO MANUALLY FILL CAPCHA")
        let onboardingPage : OnboardingPage = new OnboardingPage(multiremotebrowser['browserDriver'])
        await onboardingPage.waitForLoad()
        await onboardingPage.onboard()

        let homePage : HomePage = new HomePage(multiremotebrowser['browserDriver'])
        await homePage.waitForLoad()
        await multiremotebrowser['browserDriver'].reloadSession()
        console.log("SUCCESS creating account")
        
    })

    it('Create new playlist', async () => {
        console.log("create new playlist")
        let loginPage : LoginPage= new LoginPage(multiremotebrowser['browserDriver'])
		await loginPage.goToLoginPage()
		await loginPage.login(email, password)
        console.log("YOU MAY HAVE TO MANUALLY FILL CAPCHA")

		let homePage : HomePage  = new HomePage(multiremotebrowser['browserDriver']);
        await homePage.waitForLoad()
        await homePage.closePopups()
		await homePage.goToPlaylist()

		let playlistsPage : PlaylistsPage = new PlaylistsPage(multiremotebrowser['browserDriver']);
		await playlistsPage.createPlaylist(playlistName);
		console.log("SUCCESS");
    })


    it('check playlist on Deezer app', async () => {
        let launchActivity: LaunchActivity = new LaunchActivity(multiremotebrowser['appiumDriver'])
        await launchActivity.goToLogin()

        let emailLoginActivity: EmailLoginActivity = new EmailLoginActivity(multiremotebrowser['appiumDriver'])
        await emailLoginActivity.fillEmailAndGoToPwdPage(email)
        
        let passwordLoginActivity: PasswordLoginActivity = new PasswordLoginActivity(multiremotebrowser['appiumDriver'])
        await passwordLoginActivity.login(password)

        let homeActivity: HomeActivity = new HomeActivity(multiremotebrowser['appiumDriver'])
        await homeActivity.closeCta()
        await homeActivity.goToFavorites()

        let favoritesActivity: FavoritesActivity = new FavoritesActivity(multiremotebrowser['appiumDriver'])
        await favoritesActivity.goToPlaylists()

        let playlistsActivity: PlaylistsActivity = new PlaylistsActivity(multiremotebrowser['appiumDriver'])
        await playlistsActivity.isPlaylistPresent(playlistName)

        console.log("SUCCESS")
    });
});


