import { join } from 'path';

export const config: WebdriverIO.Config = {
    port: 4723,
    specs: [
        './test/specs/**/deezer.playlist.*.ts'
    ],
    mochaOpts: {
        ui: 'bdd',
        timeout: 60000,
        bail: true
    },
    logLevel : 'error',
    maxInstances: 10,
    capabilities: {
        browserDriver: {
            port: 9515,
            path: "/",
            capabilities: {
                browserName: 'chrome',
                "goog:chromeOptions":{
                    args : ['--start-maximized']
                }
            }
        },
        appiumDriver: {
            port: 4723,
            path: "/",
            capabilities: {
                platformName : "ANDROID",
                automationName : "UiAutomator2",
                platformVersion : "12",
                deviceName : "__Pixel_Florian",
                udid : "02CAYV0XZA",
                newCommandTimeout : 3000,
                appWaitActivity : "com.deezer.*",
                appWaitPackage : "deezer.android.app.nobilling",
                app : join(process.cwd(), '\\resources\\apps\\deezer.apk'),
                //fullReset : true,
                noReset : false
            }
        }
    },
    bail: 0,
    baseUrl: 'http://localhost',
    waitforTimeout: 20000,
    connectionRetryTimeout: 120000,
    
    connectionRetryCount: 3,
    
    services: ['chromedriver','appium'],
    
    framework: 'mocha',
    reporters: [
        //'spec',
        //'junit',
        ['allure', {outputDir: 'allure-results'}]
    ],

    
    
    /**
     * Function to be executed after a test (in Mocha/Jasmine only)
     * @param {Object}  test             test object
     * @param {Object}  context          scope object the test was executed with
     * @param {Error}   result.error     error object in case the test fails, otherwise `undefined`
     * @param {Any}     result.result    return object of test function
     * @param {Number}  result.duration  duration of test
     * @param {Boolean} result.passed    true if test has passed, otherwise false
     * @param {Object}  result.retries   informations to spec related retries, e.g. `{ attempts: 0, limit: 0 }`
     */
    afterTest: async function(test, context, { error, result, duration, passed, retries }) {
        if (!passed) {
            await browser.takeScreenshot();
        }
    },


}
