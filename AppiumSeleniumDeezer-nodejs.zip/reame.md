### Installation

- npm install
- npx wdio (pas besoin de faire tout le set up juste la commande qui sert à initaliser @wdio/cli)

### Utilisation
les scripts dans package.json 
 - npm run deezer:playlist -> lance la suite de test
 - npm run allure:report -> lance le rapport allure